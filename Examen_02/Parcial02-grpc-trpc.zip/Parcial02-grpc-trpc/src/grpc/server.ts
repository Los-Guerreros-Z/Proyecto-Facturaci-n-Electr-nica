import "dotenv/config";
import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import { fileURLToPath } from "node:url";

import {
  memoria,
  type Producto,
  type Filtro,
  type Paginacion
} from "../data/memory.js";

import {
  mongodb,
  conectarMongo,
  cerrarMongo
} from "../data/mongodb.js";

import {
  generarToken,
  verificarToken
} from "../common/auth.js";

// -----------------------------------------
// Configuracion de Protocol Buffers
// -----------------------------------------

const PROTO_PATH = fileURLToPath(
  new URL("../../proto/catalogo.proto", import.meta.url)
);

const definicion = protoLoader.loadSync(PROTO_PATH, {
  keepCase: false,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true
});

const paquete = grpc.loadPackageDefinition(definicion);
const catalogo = paquete.catalogo as grpc.GrpcObject;

const Servicio =
  catalogo.CatalogoService as grpc.ServiceClientConstructor;

// -----------------------------------------
// Seleccion del repositorio
// -----------------------------------------

const modo = process.env.DATA_SOURCE ?? "memory";

if (modo !== "memory" && modo !== "mongodb") {
  throw new Error(
    "DATA_SOURCE debe ser 'memory' o 'mongodb'"
  );
}

const repositorio = modo === "mongodb"
  ? mongodb
  : memoria;

// -----------------------------------------
// Manejo de errores
// -----------------------------------------

function errorGrpc(
  codigo: grpc.status,
  mensaje: string
): grpc.ServiceError {
  return {
    name: "ServiceError",
    message: mensaje,
    details: mensaje,
    code: codigo
  } as grpc.ServiceError;
}

function convertirError(error: unknown): grpc.ServiceError {
  if (error instanceof Error) {
    if (error.message === "Producto no encontrado") {
      return errorGrpc(
        grpc.status.NOT_FOUND,
        error.message
      );
    }

    if (
      error.message === "Datos del producto invalidos" ||
      error.message === "La categoria no existe"
    ) {
      return errorGrpc(
        grpc.status.INVALID_ARGUMENT,
        error.message
      );
    }
  }

  console.error("Error interno:", error);

  return errorGrpc(
    grpc.status.INTERNAL,
    "Error interno del servidor"
  );
}

// -----------------------------------------
// Middleware de autenticacion JWT
// -----------------------------------------

function protegido<Req, Res>(
  operacion: (datos: Req) => Res | Promise<Res>
): grpc.handleUnaryCall<Req, Res> {

  return (call, callback) => {

    const encabezado = call.metadata
      .get("authorization")[0]
      ?.toString();

    if (!encabezado?.startsWith("Bearer ")) {
      callback(
        errorGrpc(
          grpc.status.UNAUTHENTICATED,
          "Token JWT requerido"
        ),
        null
      );
      return;
    }

    const token = encabezado.slice(7);

    if (!verificarToken(token)) {
      callback(
        errorGrpc(
          grpc.status.UNAUTHENTICATED,
          "Token invalido o expirado"
        ),
        null
      );
      return;
    }

    Promise.resolve()
      .then(() => operacion(call.request))
      .then(resultado => {
        callback(null, resultado);
      })
      .catch(error => {
        callback(convertirError(error), null);
      });
  };
}

// -----------------------------------------
// Tipos utilizados
// -----------------------------------------

type Credenciales = {
  usuario: string;
  clave: string;
};

type EntradaProducto = Omit<Producto, "id">;

// -----------------------------------------
// Implementacion de procedimientos gRPC
// -----------------------------------------

const implementacion = {

  // Autenticacion
  login(
    call: grpc.ServerUnaryCall<
      Credenciales,
      { token: string }
    >,
    callback: grpc.sendUnaryData<{ token: string }>
  ) {
    const { usuario, clave } = call.request;

    if (
      usuario !== process.env.DEMO_USER ||
      clave !== process.env.DEMO_PASSWORD
    ) {
      callback(
        errorGrpc(
          grpc.status.UNAUTHENTICATED,
          "Credenciales incorrectas"
        ),
        null
      );
      return;
    }

    callback(null, {
      token: generarToken(usuario)
    });
  },

  // A. Consultar todos los registros
  listarProductos: protegido(async () => ({
    productos: await repositorio.listar()
  })),

  // B. Seleccionar campos especificos
  seleccionarCampos: protegido(async () => ({
    productos: await repositorio.seleccionarCampos()
  })),

  // C. Consultar aplicando filtros
  filtrarProductos: protegido(async (filtro: Filtro) => ({
    productos: await repositorio.filtrar(filtro)
  })),

  // D. Relaciones entre productos y categorias
  productosConCategoria: protegido(async () => ({
    productos: await repositorio.relacionar()
  })),

  // E1. Insertar producto
  crearProducto: protegido(
    async (datos: EntradaProducto) => {
      return await repositorio.crear(datos);
    }
  ),

  // E2. Actualizar producto
  actualizarProducto: protegido(
    async (datos: Producto) => {
      return await repositorio.actualizar(datos);
    }
  ),

  // E3. Eliminar producto
  eliminarProducto: protegido(
    async (datos: { id: number }) => {
      return await repositorio.eliminar(datos.id);
    }
  ),

  // F. Paginacion y ordenamiento
  paginarProductos: protegido(
    async (datos: Paginacion) => {
      return await repositorio.paginar(datos);
    }
  )
};

// -----------------------------------------
// Configuracion del servidor gRPC
// -----------------------------------------

const servidor = new grpc.Server();

servidor.addService(
  Servicio.service,
  implementacion
);

const puerto = "127.0.0.1:50051";

// -----------------------------------------
// Inicializacion del servidor
// -----------------------------------------

async function iniciarServidor(): Promise<void> {
  try {

    // Validacion de credenciales
    if (
      !process.env.JWT_SECRET ||
      process.env.JWT_SECRET.length < 32 ||
      !process.env.DEMO_USER ||
      !process.env.DEMO_PASSWORD
    ) {
      throw new Error(
        "Configuracion de autenticacion incompleta"
      );
    }

    // Conectar con MongoDB solo cuando corresponda
    if (modo === "mongodb") {
      await conectarMongo();

      console.log(
        "Conexion con MongoDB establecida correctamente"
      );
    }

    // Iniciar servidor
    servidor.bindAsync(
      puerto,
      grpc.ServerCredentials.createInsecure(),
      (error) => {

        if (error) {
          console.error(
            "Error al iniciar gRPC:",
            error
          );

          void cerrarMongo().catch(console.error);
          process.exitCode = 1;
          return;
        }

        console.log(
          `Servidor gRPC disponible en ${puerto}`
        );

        console.log(
          `Fuente de datos: ${modo}`
        );
      }
    );

  } catch (error) {
    console.error(
      "Error iniciando servidor:",
      error
    );

    await cerrarMongo();
    process.exitCode = 1;
  }
}

void iniciarServidor();