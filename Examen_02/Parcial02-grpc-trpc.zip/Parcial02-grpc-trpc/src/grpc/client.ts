import "dotenv/config";
import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import { fileURLToPath } from "node:url";

const PROTO_PATH = fileURLToPath(
  new URL("../../proto/catalogo.proto", import.meta.url)
);

const definicion = protoLoader.loadSync(PROTO_PATH, {
  keepCase: false,
  longs: String,
  enums: String,
  defaults: true
});

const paquete = grpc.loadPackageDefinition(definicion);
const catalogo = paquete.catalogo as grpc.GrpcObject;

const Servicio = catalogo.CatalogoService as grpc.ServiceClientConstructor;

const cliente = new Servicio(
  "127.0.0.1:50051",
  grpc.credentials.createInsecure()
);

let token = "";

function ejecutar<T>(
  metodo: string,
  datos: object,
  usarToken = true
): Promise<T> {

  return new Promise((resolve, reject) => {
    const metadata = new grpc.Metadata();

    if (usarToken && token) {
      metadata.set("authorization", `Bearer ${token}`);
    }

    type FuncionRPC = (
      datos: object,
      metadata: grpc.Metadata,
      callback: (error: grpc.ServiceError | null, resultado: T) => void
    ) => void;

    const procedimientos = cliente as unknown as Record<
      string,
      FuncionRPC
    >;

    procedimientos[metodo](
      datos,
      metadata,
      (error, resultado) => {
        if (error) {
          reject(error);
        } else {
          resolve(resultado);
        }
      }
    );
  });
}

function mostrar(titulo: string, datos: unknown): void {
  console.log(`\n========== ${titulo} ==========`);
  console.log(JSON.stringify(datos, null, 2));
}

async function main() {

  try {
    // Autenticacion
    const acceso = await ejecutar<{ token: string }>(
      "login",
      {
        usuario: process.env.DEMO_USER,
        clave: process.env.DEMO_PASSWORD
      },
      false
    );

    token = acceso.token;
    console.log("Autenticacion JWT correcta");

    // A. Consultar todos
    mostrar(
      "A. TODOS LOS PRODUCTOS",
      await ejecutar("listarProductos", {})
    );

    // B. Seleccionar campos
    mostrar(
      "B. CAMPOS ESPECIFICOS",
      await ejecutar("seleccionarCampos", {})
    );

    // C. Filtrar
    mostrar(
      "C. FILTRAR POR PRECIO",
      await ejecutar("filtrarProductos", {
        precioMaximo: 90
      })
    );

    // D. Relaciones
    mostrar(
      "D. PRODUCTOS CON CATEGORIAS",
      await ejecutar("productosConCategoria", {})
    );

    // E. Insertar
    // E1. Insertar producto
    const productoCreado = await ejecutar<{
    id: number;
    nombre: string;
    precio: number;
    stock: number;
    categoriaId: number;
    }>(
    "crearProducto",
    {
        nombre: "Monitor Samsung",
        precio: 250,
        stock: 12,
        categoriaId: 2
    }
    );

    mostrar("E1. INSERTAR PRODUCTO", productoCreado);

    // E2. Actualizar el producto recien creado
    mostrar(
    "E2. ACTUALIZAR PRODUCTO",
    await ejecutar("actualizarProducto", {
        id: productoCreado.id,
        nombre: "Monitor Samsung Actualizado",
        precio: 230,
        stock: 18,
        categoriaId: 2
    })
    );

    // F. Paginar y ordenar
    mostrar(
      "F. PAGINACION Y ORDENAMIENTO",
      await ejecutar("paginarProductos", {
        pagina: 1,
        limite: 3,
        ordenarPor: "precio",
        direccion: "desc"
      })
    );

    // E3. Eliminar el producto creado durante la prueba
    mostrar(
    "E3. ELIMINAR PRODUCTO",
    await ejecutar("eliminarProducto", {
        id: productoCreado.id
    })
    );

    // G. Comprobar rechazo sin JWT
    try {
      await ejecutar("listarProductos", {}, false);
      throw new Error("Fallo de seguridad: acceso sin token permitido");
    } catch (error) {
      if (
        typeof error === "object" &&
        error !== null &&
        "code" in error &&
        error.code === grpc.status.UNAUTHENTICATED
      ) {
        console.log("\nG. SEGURIDAD JWT");
        console.log("Acceso sin token correctamente rechazado");
      } else {
        throw error;
      }
    }

    console.log("\nDemostracion gRPC finalizada correctamente");

  } catch (error) {
    console.error("Error durante la demostracion:", error);
    process.exitCode = 1;
  } finally {
    cliente.close();
  }
}

void main();