export interface Categoria {
  id: number;
  nombre: string;
  descripcion: string;
}

export interface Producto {
  id: number;
  nombre: string;
  precio: number;
  stock: number;
  categoriaId: number;
}

export interface Filtro {
  nombre?: string;
  precioMaximo?: number;
  categoriaId?: number;
}

export interface Paginacion {
  pagina: number;
  limite: number;
  ordenarPor: string;
  direccion: string;
}

// Base de datos simulada en memoria
export const categorias: Categoria[] = [
  { id: 1, nombre: "Hardware", descripcion: "Componentes" },
  { id: 2, nombre: "Perifericos", descripcion: "Accesorios" },
  { id: 3, nombre: "Redes", descripcion: "Conectividad" }
];

let productos: Producto[] = [
  { id: 1, nombre: "Procesador Ryzen", precio: 180, stock: 10, categoriaId: 1 },
  { id: 2, nombre: "Memoria RAM", precio: 75, stock: 20, categoriaId: 1 },
  { id: 3, nombre: "Teclado mecanico", precio: 55, stock: 15, categoriaId: 2 },
  { id: 4, nombre: "Mouse Logitech", precio: 35, stock: 30, categoriaId: 2 },
  { id: 5, nombre: "Router TP-Link", precio: 90, stock: 8, categoriaId: 3 }
];

let siguienteId = 6;

function validarProducto(datos: Omit<Producto, "id">): void {
  if (
    !datos.nombre?.trim() ||
    !Number.isFinite(datos.precio) ||
    datos.precio < 0 ||
    !Number.isInteger(datos.stock) ||
    datos.stock < 0 ||
    !categorias.some(c => c.id === datos.categoriaId)
  ) {
    throw new Error("Datos del producto invalidos");
  }
}

export const memoria = {

  // A. Consultar todos los registros
  listar(): Producto[] {
    return productos.map(p => ({ ...p }));
  },

  // B. Seleccionar campos especificos
  seleccionarCampos() {
    return productos.map(({ id, nombre, precio }) => ({
      id,
      nombre,
      precio
    }));
  },

  // C. Aplicar filtros
  filtrar(filtro: Filtro): Producto[] {
    return productos.filter(p =>
      (!filtro.nombre ||
        p.nombre.toLowerCase().includes(filtro.nombre.toLowerCase())) &&
      (!filtro.precioMaximo || p.precio <= filtro.precioMaximo) &&
      (!filtro.categoriaId || p.categoriaId === filtro.categoriaId)
    );
  },

  // D. Relacionar productos con categorias
  relacionar() {
    return productos.map(p => ({
      ...p,
      categoriaNombre:
        categorias.find(c => c.id === p.categoriaId)?.nombre ?? "Sin categoria"
    }));
  },

  // E. Insertar
  crear(datos: Omit<Producto, "id">): Producto {
    validarProducto(datos);

    const producto = {
      ...datos,
      id: siguienteId++
    };

    productos.push(producto);
    return { ...producto };
  },

  // E. Modificar
  actualizar(datos: Producto): Producto {
    const indice = productos.findIndex(p => p.id === datos.id);

    if (indice === -1) {
      throw new Error("Producto no encontrado");
    }

    validarProducto(datos);
    productos[indice] = { ...datos };

    return { ...productos[indice] };
  },

  // E. Eliminar
  eliminar(id: number) {
    const indice = productos.findIndex(p => p.id === id);

    if (indice === -1) {
      throw new Error("Producto no encontrado");
    }

    productos.splice(indice, 1);

    return {
      eliminado: true,
      mensaje: "Producto eliminado correctamente"
    };
  },

  // F. Paginacion y ordenamiento
  paginar(opciones: Paginacion) {
    const pagina = Math.max(1, Math.trunc(opciones.pagina || 1));
    const limite = Math.max(1, Math.min(100, Math.trunc(opciones.limite || 5)));

    const camposPermitidos = ["id", "nombre", "precio", "stock"];

    const campo = camposPermitidos.includes(opciones.ordenarPor)
      ? opciones.ordenarPor as keyof Producto
      : "id";

    const factor = opciones.direccion === "desc" ? -1 : 1;

    const ordenados = [...productos].sort((a, b) => {
      const valorA = a[campo];
      const valorB = b[campo];

      if (typeof valorA === "number" && typeof valorB === "number") {
        return (valorA - valorB) * factor;
      }

      return String(valorA).localeCompare(String(valorB)) * factor;
    });

    const inicio = (pagina - 1) * limite;

    return {
      productos: ordenados.slice(inicio, inicio + limite),
      total: productos.length,
      pagina,
      limite,
      totalPaginas: Math.ceil(productos.length / limite)
    };
  }
};