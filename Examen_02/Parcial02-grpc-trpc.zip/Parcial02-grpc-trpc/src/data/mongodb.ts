import {
  MongoClient,
  type Db,
  type Filter,
  type Sort
} from "mongodb";

import type {
  Categoria,
  Producto,
  Filtro,
  Paginacion
} from "./memory.js";

let cliente: MongoClient | null = null;
let baseDatos: Db | null = null;

export async function conectarMongo(): Promise<Db> {
  const uri = process.env.MONGO_URI ??
    "mongodb://127.0.0.1:27017";

  cliente = new MongoClient(uri, {
    serverSelectionTimeoutMS: 3000
  });

  await cliente.connect();

  baseDatos = cliente.db(
    process.env.MONGO_DB ?? "parcial02_grpc"
  );

  await baseDatos.command({ ping: 1 });

  await baseDatos.collection<Producto>("productos")
    .createIndex({ id: 1 }, { unique: true });

  await baseDatos.collection<Categoria>("categorias")
    .createIndex({ id: 1 }, { unique: true });

  return baseDatos;
}

export function obtenerDB(): Db {
  if (!baseDatos) {
    throw new Error("MongoDB no esta conectado");
  }

  return baseDatos;
}

export async function cerrarMongo(): Promise<void> {
  if (cliente) {
    await cliente.close();
  }

  cliente = null;
  baseDatos = null;
}

function productos() {
  return obtenerDB().collection<Producto>("productos");
}

function categorias() {
  return obtenerDB().collection<Categoria>("categorias");
}

async function validarProducto(
  datos: Omit<Producto, "id">
): Promise<void> {
  if (
    !datos.nombre?.trim() ||
    !Number.isFinite(datos.precio) ||
    datos.precio < 0 ||
    !Number.isInteger(datos.stock) ||
    datos.stock < 0 ||
    !Number.isInteger(datos.categoriaId) ||
    datos.categoriaId <= 0
  ) {
    throw new Error("Datos del producto invalidos");
  }

  const categoria = await categorias().findOne({
    id: datos.categoriaId
  });

  if (!categoria) {
    throw new Error("La categoria no existe");
  }
}

export const mongodb = {

  // A. Consultar todos los productos
  async listar() {
    return productos()
      .find({}, { projection: { _id: 0 } })
      .sort({ id: 1 })
      .toArray();
  },

  // B. Consultar campos especificos
  async seleccionarCampos() {
    const registros = await productos().find(
      {},
      {
        projection: {
          _id: 0,
          id: 1,
          nombre: 1,
          precio: 1
        }
      }
    ).sort({ id: 1 }).toArray();

    return registros.map(({ id, nombre, precio }) => ({
      id,
      nombre,
      precio
    }));
  },

  // C. Consultar aplicando filtros
  async filtrar(filtro: Filtro) {
    const consulta: Filter<Producto> = {};

    if (filtro.nombre?.trim()) {
      const nombreSeguro = filtro.nombre.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
      );

      consulta.nombre = {
        $regex: nombreSeguro,
        $options: "i"
      };
    }

    if (
      filtro.precioMaximo !== undefined &&
      filtro.precioMaximo > 0
    ) {
      consulta.precio = {
        $lte: filtro.precioMaximo
      };
    }

    if (filtro.categoriaId && filtro.categoriaId > 0) {
      consulta.categoriaId = filtro.categoriaId;
    }

    return productos()
      .find(consulta, { projection: { _id: 0 } })
      .sort({ id: 1 })
      .toArray();
  },

  // D. Relacionar productos con categorias
  async relacionar() {
    return productos().aggregate<Producto & {
      categoriaNombre: string
    }>([
      {
        $lookup: {
          from: "categorias",
          localField: "categoriaId",
          foreignField: "id",
          as: "categoria"
        }
      },
      {
        $unwind: {
          path: "$categoria",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $addFields: {
          categoriaNombre: {
            $ifNull: [
              "$categoria.nombre",
              "Sin categoria"
            ]
          }
        }
      },
      {
        $project: {
          _id: 0,
          categoria: 0
        }
      },
      {
        $sort: { id: 1 }
      }
    ]).toArray();
  },

  // E1. Insertar producto
  async crear(datos: Omit<Producto, "id">) {
    await validarProducto(datos);

    const secuencia = await obtenerDB()
      .collection<{ _id: string; valor: number }>("secuencias")
      .findOneAndUpdate(
        { _id: "producto" },
        { $inc: { valor: 1 } },
        {
          upsert: true,
          returnDocument: "after"
        }
      );

    if (!secuencia) {
      throw new Error("No se pudo generar el ID");
    }

    const producto: Producto = {
      id: secuencia.valor,
      ...datos
    };

    await productos().insertOne(producto);

    return producto;
  },

  // E2. Actualizar producto
  async actualizar(datos: Producto) {
    await validarProducto(datos);

    const resultado = await productos().replaceOne(
      { id: datos.id },
      datos
    );

    if (resultado.matchedCount === 0) {
      throw new Error("Producto no encontrado");
    }

    return datos;
  },

  // E3. Eliminar producto
  async eliminar(id: number) {
    const resultado = await productos().deleteOne({ id });

    if (resultado.deletedCount === 0) {
      throw new Error("Producto no encontrado");
    }

    return {
      eliminado: true,
      mensaje: "Producto eliminado correctamente"
    };
  },

  // F. Paginacion y ordenamiento
  async paginar(opciones: Paginacion) {
    const pagina = Math.max(
      1,
      Math.trunc(opciones.pagina || 1)
    );

    const limite = Math.max(
      1,
      Math.min(100, Math.trunc(opciones.limite || 5))
    );

    const campos = [
      "id",
      "nombre",
      "precio",
      "stock"
    ];

    const campo = campos.includes(opciones.ordenarPor)
      ? opciones.ordenarPor
      : "id";

    const direccion = opciones.direccion === "desc"
      ? -1
      : 1;

    const orden: Sort = campo === "id"
      ? { id: direccion }
      : { [campo]: direccion, id: 1 };

    const inicio = (pagina - 1) * limite;

    const [registros, total] = await Promise.all([
      productos()
        .find({}, { projection: { _id: 0 } })
        .sort(orden)
        .skip(inicio)
        .limit(limite)
        .toArray(),

      productos().countDocuments()
    ]);

    return {
      productos: registros,
      total,
      pagina,
      limite,
      totalPaginas: Math.ceil(total / limite)
    };
  }
};