import "dotenv/config";

import {
  conectarMongo,
  cerrarMongo
} from "./mongodb.js";

import {
  categorias,
  memoria,
  type Categoria,
  type Producto
} from "./memory.js";

async function main() {
  try {
    const db = await conectarMongo();

    const coleccionCategorias =
      db.collection<Categoria>("categorias");

    const coleccionProductos =
      db.collection<Producto>("productos");

    // Insertar categorias que no existan
    await coleccionCategorias.bulkWrite(
      categorias.map(categoria => ({
        updateOne: {
          filter: { id: categoria.id },
          update: {
            $setOnInsert: categoria
          },
          upsert: true
        }
      }))
    );

    // Inicializar productos solamente si la coleccion esta vacia
    const existentes = await coleccionProductos.countDocuments();

    if (existentes === 0) {
      await coleccionProductos.insertMany(memoria.listar());
      console.log("Productos iniciales insertados");
    } else {
      console.log("La coleccion ya contiene productos");
    }

    // Sincronizar contador de identificadores
    const ultimo = await coleccionProductos
      .find({}, { projection: { id: 1, _id: 0 } })
      .sort({ id: -1 })
      .limit(1)
      .next();

    await db.collection<{
      _id: string;
      valor: number;
    }>("secuencias").updateOne(
      { _id: "producto" },
      {
        $max: {
          valor: ultimo?.id ?? 0
        }
      },
      { upsert: true }
    );

    console.log("Base de datos inicializada correctamente");

    console.log(
      "Categorias:",
      await coleccionCategorias.countDocuments()
    );

    console.log(
      "Productos:",
      await coleccionProductos.countDocuments()
    );

  } catch (error) {
    console.error("Error inicializando MongoDB:", error);
    process.exitCode = 1;
  } finally {
    await cerrarMongo();
  }
}

void main();