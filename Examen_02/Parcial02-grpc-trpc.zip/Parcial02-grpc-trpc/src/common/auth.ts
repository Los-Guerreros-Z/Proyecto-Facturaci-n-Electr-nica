import jwt from "jsonwebtoken";

function obtenerSecreto(): string {
  const secreto = process.env.JWT_SECRET;

  if (!secreto || secreto.length < 32) {
    throw new Error("JWT_SECRET debe contener al menos 32 caracteres");
  }

  return secreto;
}

export function generarToken(usuario: string): string {
  return jwt.sign(
    { rol: "admin" },
    obtenerSecreto(),
    {
      subject: usuario,
      expiresIn: "1h",
      algorithm: "HS256"
    }
  );
}

export function verificarToken(token: string): boolean {
  try {
    const datos = jwt.verify(token, obtenerSecreto(), {
      algorithms: ["HS256"]
    });

    return typeof datos !== "string" && Boolean(datos.sub);
  } catch {
    return false;
  }
}