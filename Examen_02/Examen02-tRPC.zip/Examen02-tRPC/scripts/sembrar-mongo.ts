import "dotenv/config";
import mongoose from "mongoose";
import { conectarMongo, sembrarMongo, RepositorioMongo } from "../src/repositories/mongo.js";

async function ejecutar(): Promise<void> {
  if (process.env.DB_MODE !== "mongo") throw new Error("Configura DB_MODE=mongo en .env primero");
  const uri = process.env.MONGO_URI ?? "";
  if (!/\/examen02_trpc(?:\?|$)/.test(uri)) {
    throw new Error("Por seguridad, la semilla solo admite la base dedicada /examen02_trpc");
  }
  await conectarMongo();
  try {
    await sembrarMongo();
    const repo = new RepositorioMongo();
    const conteos = await Promise.all([repo.categorias(), repo.proveedores(), repo.productos()]);
    console.log(`MongoDB listo: categorias=${conteos[0].length}, proveedores=${conteos[1].length}, productos=${conteos[2].length}`);
    console.log("Los registros existentes se conservaron; solo se insertaron los ausentes.");
  } finally {
    await mongoose.disconnect();
  }
}

 ejecutar().catch((error: unknown) => { console.error(error); process.exitCode = 1; });
