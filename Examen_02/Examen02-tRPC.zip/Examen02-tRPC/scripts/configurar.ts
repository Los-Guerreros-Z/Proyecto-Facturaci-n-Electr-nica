import { existsSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { hashSync } from "bcryptjs";

const archivo = new URL("../.env", import.meta.url);
if (existsSync(archivo)) {
  console.log("Ya existe .env: no se modificó. Para ver la configuración, abre el archivo localmente.");
} else {
  const contenido = [
    "# Solo demostración local del examen; nunca subas este archivo a Git.",
    "DB_MODE=memory",
    "PORT=4317",
    "MONGO_URI=mongodb://127.0.0.1:27017/examen02_trpc",
    "DEMO_EMAIL=demo@local.test",
    `DEMO_PASSWORD_HASH=${hashSync("Demo12345!", 10)}`,
    "DEMO_PASSWORD_CLIENT=Demo12345!",
    `JWT_SECRET=${randomBytes(48).toString("hex")}`,
    ""
  ].join("\n");
  writeFileSync(archivo, contenido, { flag: "wx", mode: 0o600 });
  console.log("Se creó .env para la demostración local. Usuario: demo@local.test / Clave: Demo12345!");
  console.log("La contraseña de demostración es pública; no usar en un sistema real.");
}
