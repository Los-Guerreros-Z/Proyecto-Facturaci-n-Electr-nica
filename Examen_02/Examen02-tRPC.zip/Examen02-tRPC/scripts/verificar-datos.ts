import assert from "node:assert/strict";
import { datosIniciales } from "../src/data.js";
import { RepositorioMemoria } from "../src/repositories/memoria.js";

async function main(): Promise<void> {
  const d = datosIniciales;
  assert.equal(d.categories.length, 8);
  assert.equal(d.suppliers.length, 29);
  assert.equal(d.products.length, 77);
  assert.equal(new Set(d.categories.map((c) => c.CategoryID)).size, 8);
  assert.equal(new Set(d.suppliers.map((s) => s.SupplierID)).size, 29);
  assert.equal(new Set(d.products.map((p) => p.ProductID)).size, 77);
  for (const p of d.products) {
    assert.ok(d.categories.some((c) => c.CategoryID === p.CategoryID));
    assert.ok(d.suppliers.some((s) => s.SupplierID === p.SupplierID));
  }
  const repo = new RepositorioMemoria();
  assert.equal((await repo.productos()).length, 77);
  const creado = await repo.insertar({
    ProductID: 999001, ProductName: "Prueba", CategoryID: 1, SupplierID: 1,
    QuantityPerUnit: "1 und", UnitPrice: 11, UnitsInStock: 3, ReorderLevel: 1
  });
  assert.equal(creado.ProductID, 999001);
  assert.equal((await repo.modificar(999001, { UnitPrice: 12 }))?.UnitPrice, 12);
  assert.equal((await repo.eliminar(999001))?.ProductID, 999001);
  assert.equal((await repo.productos()).length, 77);
  console.log("OK: datos Northwind validados y CRUD en memoria verificado (8/29/77).");
}
main().catch((error: unknown) => { console.error(error); process.exitCode = 1; });
