import "dotenv/config";
import { createHTTPServer } from "@trpc/server/adapters/standalone";
import { appRouter } from "./router.js";
import { construirContexto } from "./context.js";
import { RepositorioMemoria } from "../repositories/memoria.js";
import { RepositorioMongo, conectarMongo } from "../repositories/mongo.js";
import type { Repositorio } from "../types.js";

async function iniciar(): Promise<void> {
  const modo = (process.env.DB_MODE ?? "memory").toLowerCase();
  let repo: Repositorio;
  if (modo === "mongo") {
    await conectarMongo();
    repo = new RepositorioMongo();
  } else if (modo === "memory") {
    repo = new RepositorioMemoria();
  } else {
    throw new Error("DB_MODE debe ser memory o mongo");
  }

  const puerto = Number(process.env.PORT ?? 4317);
  if (!Number.isInteger(puerto) || puerto < 1 || puerto > 65535) throw new Error("PORT inválido");
  const servidor = createHTTPServer({ router: appRouter, createContext: construirContexto(repo) });
  servidor.on("error", (error: NodeJS.ErrnoException) => {
    if (error.code === "EADDRINUSE") {
      console.error(`Puerto ${puerto} ocupado. Cambia PORT en .env y reinicia.`);
    } else {
      console.error(error);
    }
    process.exitCode = 1;
  });
  servidor.listen(puerto, "127.0.0.1", () => {
    console.log(`Servidor tRPC listo | modo=${modo} | http://127.0.0.1:${puerto}`);
    console.log(`Prueba: http://127.0.0.1:${puerto}/productos.todos`);
  });
}

iniciar().catch((error: unknown) => {
  console.error("No se pudo iniciar el servidor:", error);
  process.exitCode = 1;
});
