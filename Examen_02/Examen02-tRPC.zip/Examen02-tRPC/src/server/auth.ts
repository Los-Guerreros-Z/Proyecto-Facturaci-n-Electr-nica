import bcrypt from "bcryptjs";
import jwt, { type JwtPayload } from "jsonwebtoken";

export interface Usuario { email: string; rol: "admin"; }

function secreto(): string {
  const valor = process.env.JWT_SECRET;
  if (!valor || valor.length < 32) {
    throw new Error("JWT_SECRET no configurado. Ejecuta npm run setup.");
  }
  return valor;
}

export async function autenticar(email: string, password: string): Promise<{ token: string; usuario: Usuario } | null> {
  const correo = process.env.DEMO_EMAIL;
  const hash = process.env.DEMO_PASSWORD_HASH;
  if (!correo || !hash) throw new Error("Usuario de demostración no configurado. Ejecuta npm run setup.");
  if (email !== correo || !(await bcrypt.compare(password, hash))) return null;
  const usuario: Usuario = { email: correo, rol: "admin" };
  const token = jwt.sign({ rol: usuario.rol }, secreto(), {
    algorithm: "HS256", subject: usuario.email, expiresIn: "1h", issuer: "examen02-trpc"
  });
  return { token, usuario };
}

export function usuarioDesdeToken(authorization: string | undefined): Usuario | null {
  if (!authorization?.startsWith("Bearer ")) return null;
  try {
    const datos = jwt.verify(authorization.substring(7), secreto(), {
      algorithms: ["HS256"], issuer: "examen02-trpc"
    }) as JwtPayload;
    if (typeof datos.sub !== "string" || datos.sub !== process.env.DEMO_EMAIL || datos.rol !== "admin") return null;
    return { email: datos.sub, rol: "admin" };
  } catch {
    return null;
  }
}
