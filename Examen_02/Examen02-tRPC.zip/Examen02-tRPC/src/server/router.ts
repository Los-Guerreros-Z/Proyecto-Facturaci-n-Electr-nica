import { initTRPC, TRPCError } from "@trpc/server";
import { z } from "zod";
import type { Contexto } from "./context.js";
import { autenticar } from "./auth.js";
import type { Producto } from "../types.js";

const t = initTRPC.context<Contexto>().create();
const publico = t.procedure;
const protegido = t.procedure.use(({ ctx, next }) => {
  if (!ctx.usuario) throw new TRPCError({ code: "UNAUTHORIZED", message: "Se requiere JWT válido" });
  return next({ ctx: { usuario: ctx.usuario } });
});

const id = z.number().int().positive();
const campoProducto = z.enum([
  "ProductID", "ProductName", "SupplierID", "CategoryID",
  "QuantityPerUnit", "UnitPrice", "UnitsInStock", "ReorderLevel"
]);
const datosProducto = z.object({
  ProductID: id,
  ProductName: z.string().trim().min(2).max(150),
  SupplierID: id,
  CategoryID: id,
  QuantityPerUnit: z.string().trim().min(1).max(150),
  UnitPrice: z.number().nonnegative(),
  UnitsInStock: z.number().int().nonnegative(),
  ReorderLevel: z.number().int().nonnegative()
}).strict();
const cambiosProducto = datosProducto.omit({ ProductID: true }).partial().refine(
  (cambios) => Object.keys(cambios).length > 0,
  { message: "Indica al menos un campo para modificar" }
);

async function validarRelaciones(repo: Contexto["repo"], producto: Pick<Producto, "CategoryID" | "SupplierID">): Promise<void> {
  const [categorias, proveedores] = await Promise.all([repo.categorias(), repo.proveedores()]);
  if (!categorias.some((c) => c.CategoryID === producto.CategoryID)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "CategoryID no existe" });
  }
  if (!proveedores.some((p) => p.SupplierID === producto.SupplierID)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "SupplierID no existe" });
  }
}

function traducirError(error: unknown): never {
  if (error instanceof Error && (error.message === "PRODUCTO_DUPLICADO" ||
    ("code" in error && error.code === 11000))) {
    throw new TRPCError({ code: "CONFLICT", message: "ProductID ya existe" });
  }
  throw error;
}

export const appRouter = t.router({
  auth: t.router({
    login: publico.input(z.object({ email: z.email(), password: z.string().min(1) }))
      .mutation(async ({ input }) => {
        const acceso = await autenticar(input.email, input.password);
        if (!acceso) throw new TRPCError({ code: "UNAUTHORIZED", message: "Credenciales incorrectas" });
        return acceso;
      }),
    perfil: protegido.query(({ ctx }) => ctx.usuario)
  }),

  categorias: t.router({
    todas: publico.query(({ ctx }) => ctx.repo.categorias())
  }),

  proveedores: t.router({
    todos: publico.query(({ ctx }) => ctx.repo.proveedores())
  }),

  productos: t.router({
    // A. Todos los registros
    todos: publico.query(({ ctx }) => ctx.repo.productos()),
    uno: publico.input(z.object({ ProductID: id })).query(async ({ input, ctx }) =>
      ctx.repo.productoPorId(input.ProductID)),

    // B. Proyección de campos elegidos por el cliente
    campos: publico.input(z.object({ campos: z.array(campoProducto).min(1) }))
      .query(async ({ input, ctx }) => (await ctx.repo.productos()).map((producto) => {
        const seleccionado: Record<string, string | number> = {};
        for (const campo of input.campos) seleccionado[campo] = producto[campo];
        return seleccionado;
      })),

    // C. Filtros
    filtrar: publico.input(z.object({
      categoriaId: id.optional(),
      proveedorId: id.optional(),
      nombre: z.string().trim().optional(),
      precioMinimo: z.number().nonnegative().optional(),
      precioMaximo: z.number().nonnegative().optional()
    }).refine((v) => v.precioMinimo === undefined || v.precioMaximo === undefined ||
      v.precioMinimo <= v.precioMaximo, { message: "precioMinimo debe ser <= precioMaximo" }))
      .query(async ({ ctx, input }) => (await ctx.repo.productos()).filter((p) =>
        (input.categoriaId === undefined || p.CategoryID === input.categoriaId) &&
        (input.proveedorId === undefined || p.SupplierID === input.proveedorId) &&
        (input.nombre === undefined || p.ProductName.toLowerCase().includes(input.nombre.toLowerCase())) &&
        (input.precioMinimo === undefined || p.UnitPrice >= input.precioMinimo) &&
        (input.precioMaximo === undefined || p.UnitPrice <= input.precioMaximo)
      )),

    // D. JOIN entre productos, categorías y proveedores
    relaciones: publico.query(async ({ ctx }) => {
      const [productos, categorias, proveedores] = await Promise.all([
        ctx.repo.productos(), ctx.repo.categorias(), ctx.repo.proveedores()
      ]);
      const porCategoria = new Map(categorias.map((c) => [c.CategoryID, c]));
      const porProveedor = new Map(proveedores.map((p) => [p.SupplierID, p]));
      return productos.map((p) => ({
        ...p, Categoria: porCategoria.get(p.CategoryID) ?? null,
        Proveedor: porProveedor.get(p.SupplierID) ?? null
      }));
    }),

    // D. Agregación: conteo de productos y precio promedio por categoría
    agregacion: publico.query(async ({ ctx }) => {
      const [productos, categorias] = await Promise.all([ctx.repo.productos(), ctx.repo.categorias()]);
      return categorias.map((categoria) => {
        const lista = productos.filter((p) => p.CategoryID === categoria.CategoryID);
        const suma = lista.reduce((acum, p) => acum + p.UnitPrice, 0);
        return {
          CategoryID: categoria.CategoryID,
          CategoryName: categoria.CategoryName,
          totalProductos: lista.length,
          precioPromedio: lista.length ? Math.round((suma / lista.length) * 100) / 100 : 0
        };
      });
    }),

    // F. Paginación y ordenamiento
    paginar: publico.input(z.object({
      pagina: z.number().int().positive().default(1),
      limite: z.number().int().min(1).max(100).default(5),
      ordenarPor: campoProducto.default("ProductID"),
      direccion: z.enum(["asc", "desc"]).default("asc")
    })).query(async ({ ctx, input }) => {
      const registros = await ctx.repo.productos();
      const ordenados = [...registros].sort((a, b) => {
        const comparacion = typeof a[input.ordenarPor] === "string"
          ? String(a[input.ordenarPor]).localeCompare(String(b[input.ordenarPor]))
          : Number(a[input.ordenarPor]) - Number(b[input.ordenarPor]);
        return input.direccion === "asc" ? comparacion : -comparacion;
      });
      const inicio = (input.pagina - 1) * input.limite;
      return {
        pagina: input.pagina, limite: input.limite, total: registros.length,
        totalPaginas: Math.ceil(registros.length / input.limite),
        resultados: ordenados.slice(inicio, inicio + input.limite)
      };
    }),

    // E + G. CRUD protegido por JWT
    crear: protegido.input(datosProducto).mutation(async ({ ctx, input }) => {
      await validarRelaciones(ctx.repo, input);
      try { return await ctx.repo.insertar(input); } catch (error) { return traducirError(error); }
    }),
    actualizar: protegido.input(z.object({ ProductID: id, cambios: cambiosProducto }))
      .mutation(async ({ ctx, input }) => {
        const original = await ctx.repo.productoPorId(input.ProductID);
        if (!original) throw new TRPCError({ code: "NOT_FOUND", message: "Producto no encontrado" });
        await validarRelaciones(ctx.repo, { ...original, ...input.cambios });
        const actualizado = await ctx.repo.modificar(input.ProductID, input.cambios);
        if (!actualizado) throw new TRPCError({ code: "NOT_FOUND" });
        return actualizado;
      }),
    eliminar: protegido.input(z.object({ ProductID: id })).mutation(async ({ ctx, input }) => {
      const eliminado = await ctx.repo.eliminar(input.ProductID);
      if (!eliminado) throw new TRPCError({ code: "NOT_FOUND", message: "Producto no encontrado" });
      return eliminado;
    })
  })
});

export type AppRouter = typeof appRouter;
