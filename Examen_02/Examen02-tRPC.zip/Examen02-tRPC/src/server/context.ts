import type { CreateHTTPContextOptions } from "@trpc/server/adapters/standalone";
import type { Repositorio } from "../types.js";
import { usuarioDesdeToken, type Usuario } from "./auth.js";

export interface Contexto {
  repo: Repositorio;
  usuario: Usuario | null;
}

export function construirContexto(repo: Repositorio) {
  return ({ req }: CreateHTTPContextOptions): Contexto => ({
    repo,
    usuario: usuarioDesdeToken(req.headers.authorization)
  });
}
