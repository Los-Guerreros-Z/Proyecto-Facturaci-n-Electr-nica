import "dotenv/config";
import assert from "node:assert/strict";
import { randomInt } from "node:crypto";
import { createTRPCClient, httpBatchLink } from "@trpc/client";
import type { AppRouter } from "../server/router.js";
import type { NuevoProducto } from "../types.js";

const puerto = Number(process.env.PORT ?? 4317);
let token = "";
const cliente = createTRPCClient<AppRouter>({
  links: [httpBatchLink({
    url: `http://127.0.0.1:${puerto}`,
    headers: () => token ? { authorization: `Bearer ${token}` } : {}
  })]
});

function paso(etiqueta: string, descripcion: string, resultado: unknown): void {
  console.log(`\n========== ${etiqueta}: ${descripcion} ==========`);
  console.log(JSON.stringify(resultado, null, 2));
}

async function probar(): Promise<void> {
  // Datos base compartidos con la práctica de GraphQL de Semana 9.
  const [categorias, proveedores, todos] = await Promise.all([
    cliente.categorias.todas.query(),
    cliente.proveedores.todos.query(),
    cliente.productos.todos.query()
  ]);
  assert.ok(categorias.length >= 8, "Deben existir al menos ocho categorías");
  assert.ok(proveedores.length >= 29, "Deben existir al menos 29 proveedores");
  assert.ok(todos.length >= 77, "Deben existir al menos 77 productos");
  paso("A", "CONSULTAR TODOS", { total: todos.length, primeros: todos.slice(0, 3) });

  const campos = await cliente.productos.campos.query({
    campos: ["ProductID", "ProductName", "UnitPrice"]
  });
  assert.equal(campos.length, todos.length);
  assert.deepEqual(Object.keys(campos[0]).sort(), ["ProductID", "ProductName", "UnitPrice"].sort());
  paso("B", "SELECCIONAR CAMPOS", { total: campos.length, primeros: campos.slice(0, 3) });

  const filtrados = await cliente.productos.filtrar.query({ categoriaId: 1, precioMinimo: 15 });
  assert.ok(filtrados.length > 0);
  assert.ok(filtrados.every((p) => p.CategoryID === 1 && p.UnitPrice >= 15));
  paso("C", "FILTROS", { total: filtrados.length, primeros: filtrados.slice(0, 3) });

  const relaciones = await cliente.productos.relaciones.query();
  assert.equal(relaciones.length, todos.length);
  assert.ok(relaciones.every((p) => p.Categoria && p.Proveedor));
  paso("D1", "JOIN PRODUCTOS + CATEGORIAS + PROVEEDORES", relaciones.slice(0, 2));

  const resumen = await cliente.productos.agregacion.query();
  assert.equal(resumen.length, categorias.length);
  assert.equal(resumen.reduce((s, c) => s + c.totalProductos, 0), todos.length);
  paso("D2", "AGREGACION POR CATEGORIA", resumen);

  const pagina = await cliente.productos.paginar.query({
    pagina: 1, limite: 5, ordenarPor: "UnitPrice", direccion: "desc"
  });
  assert.equal(pagina.total, todos.length);
  assert.equal(pagina.resultados.length, 5);
  assert.ok(pagina.resultados.every((p, i, a) => i === 0 || a[i - 1].UnitPrice >= p.UnitPrice));
  paso("F", "PAGINACION Y ORDENAMIENTO", pagina);

  const producto: NuevoProducto = {
    ProductID: 900000000 + randomInt(10000000),
    ProductName: "Producto examen tRPC",
    CategoryID: 1,
    SupplierID: 1,
    QuantityPerUnit: "1 caja",
    UnitPrice: 45.5,
    UnitsInStock: 12,
    ReorderLevel: 3
  };

  // Debe rechazar mutaciones no autenticadas.
  let rechazo = false;
  try {
    await cliente.productos.crear.mutate(producto);
  } catch (error) {
    rechazo = (error as { data?: { code?: string } }).data?.code === "UNAUTHORIZED";
    if (!rechazo) throw error;
  }
  assert.ok(rechazo, "Se esperaba rechazo UNAUTHORIZED sin JWT");
  paso("G1", "ACCESO SIN JWT BLOQUEADO", { resultado: "UNAUTHORIZED (esperado)" });

  const email = process.env.DEMO_EMAIL;
  const password = process.env.DEMO_PASSWORD_CLIENT;
  if (!email || !password) throw new Error("Faltan DEMO_EMAIL o DEMO_PASSWORD_CLIENT: ejecuta npm run setup");
  const acceso = await cliente.auth.login.mutate({ email, password });
  token = acceso.token;
  const perfil = await cliente.auth.perfil.query();
  assert.equal(perfil.email, email);
  paso("G2", "LOGIN JWT Y ACCESO PROTEGIDO", { perfil, tokenGenerado: Boolean(token) });

  // CRUD con recuperación tras error para no dejar datos de pruebas.
  let creado = false;
  try {
    const nuevo = await cliente.productos.crear.mutate(producto);
    creado = true;
    assert.equal(nuevo.ProductID, producto.ProductID);
    paso("E1", "INSERTAR", nuevo);

    const editado = await cliente.productos.actualizar.mutate({
      ProductID: producto.ProductID,
      cambios: { ProductName: "Producto tRPC actualizado", UnitPrice: 59.9 }
    });
    assert.equal(editado.ProductName, "Producto tRPC actualizado");
    assert.equal(editado.UnitPrice, 59.9);
    paso("E2", "MODIFICAR", editado);

    const borrado = await cliente.productos.eliminar.mutate({ ProductID: producto.ProductID });
    creado = false;
    assert.equal(borrado.ProductID, producto.ProductID);
    const despues = await cliente.productos.uno.query({ ProductID: producto.ProductID });
    assert.equal(despues, null);
    paso("E3", "ELIMINAR", { eliminado: borrado, verificacion: despues });
  } finally {
    if (creado) await cliente.productos.eliminar.mutate({ ProductID: producto.ProductID });
  }

  console.log("\nTODAS LAS PRUEBAS tRPC FINALIZARON CORRECTAMENTE.");
}

probar().catch((error: unknown) => {
  console.error("\nFALLO EN LAS PRUEBAS:", error);
  process.exitCode = 1;
});
