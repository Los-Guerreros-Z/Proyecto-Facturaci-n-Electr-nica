export interface Categoria {
  CategoryID: number;
  CategoryName: string;
  Description: string;
}

export interface Proveedor {
  SupplierID: number;
  CompanyName: string;
  ContactName: string;
  ContactTitle: string;
  Country: string;
  City: string;
  Address: string;
}

export interface Producto {
  ProductID: number;
  ProductName: string;
  SupplierID: number;
  CategoryID: number;
  QuantityPerUnit: string;
  UnitPrice: number;
  UnitsInStock: number;
  ReorderLevel: number;
}

export type NuevoProducto = Producto;
export type CambioProducto = Partial<Omit<Producto, "ProductID">>;

export interface Repositorio {
  categorias(): Promise<Categoria[]>;
  proveedores(): Promise<Proveedor[]>;
  productos(): Promise<Producto[]>;
  productoPorId(id: number): Promise<Producto | null>;
  insertar(producto: NuevoProducto): Promise<Producto>;
  modificar(id: number, cambios: CambioProducto): Promise<Producto | null>;
  eliminar(id: number): Promise<Producto | null>;
}

export interface DatosNorthwind {
  categories: Categoria[];
  products: Producto[];
  suppliers: Proveedor[];
}
