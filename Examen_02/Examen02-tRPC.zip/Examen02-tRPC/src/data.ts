import { readFileSync } from "node:fs";
import type { DatosNorthwind } from "./types.js";

// Archivo tomado de los datos en memoria de Semana 9, sin copiar sus credenciales.
export const datosIniciales: DatosNorthwind = JSON.parse(
  readFileSync(new URL("../data/northwind.json", import.meta.url), "utf8")
) as DatosNorthwind;
