import mongoose, { Schema } from "mongoose";
import type { Categoria, Proveedor, Producto, NuevoProducto, CambioProducto, Repositorio } from "../types.js";
import { datosIniciales } from "../data.js";

// Colecciones dedicadas al examen; se exige conexión real cuando DB_MODE=mongo.
const categoriaSchema = new Schema({
  CategoryID: { type: Number, required: true, unique: true },
  CategoryName: { type: String, required: true },
  Description: { type: String, required: true }
}, { collection: "categories", versionKey: false });

const proveedorSchema = new Schema({
  SupplierID: { type: Number, required: true, unique: true },
  CompanyName: { type: String, required: true },
  ContactName: { type: String, required: true },
  ContactTitle: { type: String, required: true },
  Country: { type: String, required: true },
  City: { type: String, required: true },
  Address: { type: String, required: true }
}, { collection: "suppliers", versionKey: false });

const productoSchema = new Schema({
  ProductID: { type: Number, required: true, unique: true },
  ProductName: { type: String, required: true },
  SupplierID: { type: Number, required: true },
  CategoryID: { type: Number, required: true },
  QuantityPerUnit: { type: String, required: true },
  UnitPrice: { type: Number, required: true, min: 0 },
  UnitsInStock: { type: Number, required: true, min: 0 },
  ReorderLevel: { type: Number, required: true, min: 0 }
}, { collection: "products", versionKey: false });

const CategoriaModel = mongoose.model("ExamenCategoria", categoriaSchema);
const ProveedorModel = mongoose.model("ExamenProveedor", proveedorSchema);
const ProductoModel = mongoose.model("ExamenProducto", productoSchema);

function sinMongo<T>(doc: Record<string, unknown> | null): T | null {
  if (!doc) return null;
  const { _id, __v, ...campos } = doc;
  return campos as T;
}

export class RepositorioMongo implements Repositorio {
  async categorias(): Promise<Categoria[]> {
    return (await CategoriaModel.find().sort({ CategoryID: 1 }).lean())
      .map((d) => sinMongo<Categoria>(d as Record<string, unknown>)!);
  }
  async proveedores(): Promise<Proveedor[]> {
    return (await ProveedorModel.find().sort({ SupplierID: 1 }).lean())
      .map((d) => sinMongo<Proveedor>(d as Record<string, unknown>)!);
  }
  async productos(): Promise<Producto[]> {
    return (await ProductoModel.find().sort({ ProductID: 1 }).lean())
      .map((d) => sinMongo<Producto>(d as Record<string, unknown>)!);
  }
  async productoPorId(id: number): Promise<Producto | null> {
    const doc = await ProductoModel.findOne({ ProductID: id }).lean();
    return sinMongo<Producto>(doc as Record<string, unknown> | null);
  }
  async insertar(producto: NuevoProducto): Promise<Producto> {
    const creado = await ProductoModel.create(producto);
    return sinMongo<Producto>(creado.toObject() as Record<string, unknown>)!;
  }
  async modificar(id: number, cambios: CambioProducto): Promise<Producto | null> {
    const doc = await ProductoModel.findOneAndUpdate(
      { ProductID: id }, { $set: cambios }, { new: true, runValidators: true }
    ).lean();
    return sinMongo<Producto>(doc as Record<string, unknown> | null);
  }
  async eliminar(id: number): Promise<Producto | null> {
    const doc = await ProductoModel.findOneAndDelete({ ProductID: id }).lean();
    return sinMongo<Producto>(doc as Record<string, unknown> | null);
  }
}

export async function conectarMongo(): Promise<void> {
  const uri = process.env.MONGO_URI;
  if (!uri) throw new Error("Falta MONGO_URI en .env");
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
}

// No borra ni sobrescribe documentos existentes. Se usa sólo en la base del examen.
export async function sembrarMongo(): Promise<void> {
  await CategoriaModel.bulkWrite(datosIniciales.categories.map((dato) => ({
    updateOne: { filter: { CategoryID: dato.CategoryID }, update: { $setOnInsert: dato }, upsert: true }
  })));
  await ProveedorModel.bulkWrite(datosIniciales.suppliers.map((dato) => ({
    updateOne: { filter: { SupplierID: dato.SupplierID }, update: { $setOnInsert: dato }, upsert: true }
  })));
  await ProductoModel.bulkWrite(datosIniciales.products.map((dato) => ({
    updateOne: { filter: { ProductID: dato.ProductID }, update: { $setOnInsert: dato }, upsert: true }
  })));
}
