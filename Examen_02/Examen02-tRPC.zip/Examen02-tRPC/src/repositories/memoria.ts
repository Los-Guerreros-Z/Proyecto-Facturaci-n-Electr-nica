import { datosIniciales } from "../data.js";
import type { Categoria, Proveedor, Producto, NuevoProducto, CambioProducto, Repositorio } from "../types.js";

export class RepositorioMemoria implements Repositorio {
  private readonly listaCategorias: Categoria[];
  private readonly listaProveedores: Proveedor[];
  private readonly listaProductos: Producto[];

  constructor() {
    // No se modifica el JSON original; los cambios se pierden al reiniciar.
    this.listaCategorias = structuredClone(datosIniciales.categories);
    this.listaProveedores = structuredClone(datosIniciales.suppliers);
    this.listaProductos = structuredClone(datosIniciales.products);
  }

  async categorias(): Promise<Categoria[]> { return structuredClone(this.listaCategorias); }
  async proveedores(): Promise<Proveedor[]> { return structuredClone(this.listaProveedores); }
  async productos(): Promise<Producto[]> { return structuredClone(this.listaProductos); }

  async productoPorId(id: number): Promise<Producto | null> {
    const encontrado = this.listaProductos.find((p) => p.ProductID === id);
    return encontrado ? structuredClone(encontrado) : null;
  }

  async insertar(producto: NuevoProducto): Promise<Producto> {
    if (this.listaProductos.some((p) => p.ProductID === producto.ProductID)) {
      throw new Error("PRODUCTO_DUPLICADO");
    }
    this.listaProductos.push(structuredClone(producto));
    return structuredClone(producto);
  }

  async modificar(id: number, cambios: CambioProducto): Promise<Producto | null> {
    const i = this.listaProductos.findIndex((p) => p.ProductID === id);
    if (i === -1) return null;
    this.listaProductos[i] = { ...this.listaProductos[i], ...structuredClone(cambios) };
    return structuredClone(this.listaProductos[i]);
  }

  async eliminar(id: number): Promise<Producto | null> {
    const i = this.listaProductos.findIndex((p) => p.ProductID === id);
    if (i === -1) return null;
    const [eliminado] = this.listaProductos.splice(i, 1);
    return structuredClone(eliminado);
  }
}
